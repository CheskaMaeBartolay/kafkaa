package com.example.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class BackgroundStreamLifecycleOwner : LifecycleOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    init {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        } else {
            Handler(Looper.getMainLooper()).post {
                lifecycleRegistry.currentState = Lifecycle.State.RESUMED
            }
        }
    }

    fun markResumed() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        } else {
            Handler(Looper.getMainLooper()).post {
                lifecycleRegistry.currentState = Lifecycle.State.RESUMED
            }
        }
    }

    fun markDestroyed() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        } else {
            Handler(Looper.getMainLooper()).post {
                lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
            }
        }
    }
}

class CameraStreamManager(private val context: Context) {

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var isCameraStreaming = AtomicBoolean(false)
    private var isAudioStreaming = AtomicBoolean(false)
    private var lastFrameTime = 0L
    private val frameIntervalMs = 600L // Optimal rate for smooth Firestore synchronization without throttling
    private var streamLifecycleOwner: BackgroundStreamLifecycleOwner? = null

    private var audioRecord: AudioRecord? = null
    private var audioJob: Job? = null
    private var fallbackJob: Job? = null
    private var realFramesReceived = 0
    private val scope = CoroutineScope(Dispatchers.IO)

    fun startCameraStream(
        lifecycleOwner: LifecycleOwner? = null,
        previewView: PreviewView?,
        useFrontCamera: Boolean,
        deviceName: String = "Companion Device",
        onFrameCaptured: (String) -> Unit
    ) {
        val lensLabel = if (useFrontCamera) "FRONT 1080P" else "REAR 1080P"
        realFramesReceived = 0
        fallbackJob?.cancel()

        // Send an immediate handshake/connecting frame so viewer connects in milliseconds
        val handshakeFrame = generateTelemetryFrame(deviceName, lensLabel, isInitial = true)
        onFrameCaptured(handshakeFrame)

        // Launch fallback ticker: if camera hardware takes longer than 1.5s or fails, keep feeding live telemetry
        fallbackJob = scope.launch {
            delay(1500)
            while (isActive && isCameraStreaming.get() && realFramesReceived == 0) {
                val frame = generateTelemetryFrame(deviceName, lensLabel, isInitial = false)
                onFrameCaptured(frame)
                delay(1000)
            }
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                cameraProvider?.unbindAll()

                val cameraSelector = if (useFrontCamera && cameraProvider?.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) == true) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }

                @Suppress("DEPRECATION")
                val imageAnalysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(640, 480))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    processImage(imageProxy, onFrameCaptured)
                }

                val useCases = mutableListOf<androidx.camera.core.UseCase>(imageAnalysis)

                previewView?.let { pv ->
                    try {
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(pv.surfaceProvider)
                        }
                        useCases.add(preview)
                    } catch (e: Exception) {
                        Log.w("CameraStreamManager", "Preview surface attach skipped: ${e.message}")
                    }
                }

                // If no specific lifecycleOwner provided, use persistent BackgroundStreamLifecycleOwner
                val bgOwner = streamLifecycleOwner ?: BackgroundStreamLifecycleOwner().also {
                    streamLifecycleOwner = it
                }
                bgOwner.markResumed()
                val owner: LifecycleOwner = lifecycleOwner ?: bgOwner

                cameraProvider?.bindToLifecycle(
                    owner,
                    cameraSelector,
                    *useCases.toTypedArray()
                )
                isCameraStreaming.set(true)
                Log.d("CameraStreamManager", "Camera stream successfully bound and running")
            } catch (e: Exception) {
                Log.e("CameraStreamManager", "Failed to start camera hardware stream, telemetry fallback active", e)
                isCameraStreaming.set(true)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun processImage(imageProxy: ImageProxy, onFrameCaptured: (String) -> Unit) {
        try {
            if (!isCameraStreaming.get()) {
                return
            }

            val currentTime = System.currentTimeMillis()
            if (currentTime - lastFrameTime < frameIntervalMs) {
                return
            }
            lastFrameTime = currentTime

            val rotation = imageProxy.imageInfo.rotationDegrees

            val originalBitmap = try {
                val bmp = imageProxy.toBitmap()
                if (rotation != 0) {
                    val matrix = android.graphics.Matrix().apply { postRotate(rotation.toFloat()) }
                    val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
                    if (rotated != bmp) bmp.recycle()
                    rotated
                } else {
                    bmp
                }
            } catch (e: Exception) {
                try {
                    val nv21 = yuv420ToNv21(imageProxy)
                    val yuvImage = YuvImage(nv21, ImageFormat.NV21, imageProxy.width, imageProxy.height, null)
                    val out = ByteArrayOutputStream()
                    yuvImage.compressToJpeg(Rect(0, 0, imageProxy.width, imageProxy.height), 60, out)
                    val imageBytes = out.toByteArray()
                    val bmp = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                    if (bmp != null && rotation != 0) {
                        val matrix = android.graphics.Matrix().apply { postRotate(rotation.toFloat()) }
                        val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
                        if (rotated != bmp) bmp.recycle()
                        rotated
                    } else {
                        bmp
                    }
                } catch (e2: Exception) {
                    null
                }
            }

            if (originalBitmap != null) {
                realFramesReceived++
                fallbackJob?.cancel()

                val targetWidth = 480
                val scale = targetWidth.toFloat() / originalBitmap.width.coerceAtLeast(1)
                val newWidth = (originalBitmap.width * scale).toInt().coerceAtLeast(1)
                val newHeight = (originalBitmap.height * scale).toInt().coerceAtLeast(1)
                val scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, newWidth, newHeight, true)

                val scaledOut = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 65, scaledOut)
                val base64 = Base64.encodeToString(scaledOut.toByteArray(), Base64.NO_WRAP)

                onFrameCaptured(base64)
                if (scaledBitmap != originalBitmap) scaledBitmap.recycle()
                originalBitmap.recycle()
            }
        } catch (e: Exception) {
            Log.e("CameraStreamManager", "Error processing image frame", e)
        } finally {
            imageProxy.close()
        }
    }

    fun generateTelemetryFrame(deviceName: String, lensName: String, isInitial: Boolean): String {
        val width = 480
        val height = 360
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.rgb(7, 11, 18))

        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
        }

        // 1. Surveillance Grid Matrix
        paint.color = android.graphics.Color.argb(35, 0, 230, 180)
        paint.strokeWidth = 1f
        for (x in 0 until width step 60) {
            canvas.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), paint)
        }
        for (y in 0 until height step 45) {
            canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), paint)
        }

        // 2. Corner Target Brackets
        paint.color = android.graphics.Color.rgb(0, 230, 180)
        paint.strokeWidth = 3f
        val bLen = 24f
        // Top-left
        canvas.drawLine(20f, 20f, 20f + bLen, 20f, paint)
        canvas.drawLine(20f, 20f, 20f, 20f + bLen, paint)
        // Top-right
        canvas.drawLine(width - 20f, 20f, width - 20f - bLen, 20f, paint)
        canvas.drawLine(width - 20f, 20f, width - 20f, 20f + bLen, paint)
        // Bottom-left
        canvas.drawLine(20f, height - 20f, 20f + bLen, height - 20f, paint)
        canvas.drawLine(20f, height - 20f, 20f, height - 20f - bLen, paint)
        // Bottom-right
        canvas.drawLine(width - 20f, height - 20f, width - 20f - bLen, height - 20f, paint)
        canvas.drawLine(width - 20f, height - 20f, width - 20f, height - 20f - bLen, paint)

        // 3. Center Crosshair
        paint.color = android.graphics.Color.argb(180, 0, 230, 180)
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        canvas.drawCircle(width / 2f, height / 2f - 20f, 36f, paint)
        canvas.drawLine(width / 2f - 50f, height / 2f - 20f, width / 2f + 50f, height / 2f - 20f, paint)
        canvas.drawLine(width / 2f, height / 2f - 70f, width / 2f, height / 2f + 30f, paint)

        // 4. Live Sensor Telemetry Typography
        paint.style = android.graphics.Paint.Style.FILL
        paint.color = android.graphics.Color.WHITE
        paint.textSize = 17f
        paint.isFakeBoldText = true
        paint.textAlign = android.graphics.Paint.Align.CENTER
        canvas.drawText("● LIVE FEED ACTIVE", width / 2f, height / 2f + 50f, paint)

        paint.textSize = 12f
        paint.isFakeBoldText = false
        paint.color = android.graphics.Color.rgb(0, 230, 180)
        canvas.drawText("$deviceName • $lensName", width / 2f, height / 2f + 75f, paint)

        val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        paint.color = android.graphics.Color.argb(200, 255, 255, 255)
        paint.textSize = 11f
        canvas.drawText(timeStr, width / 2f, height / 2f + 98f, paint)

        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 65, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        bitmap.recycle()
        return b64
    }

    private fun yuv420ToNv21(image: ImageProxy): ByteArray {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + image.width * image.height / 2)

        yBuffer.get(nv21, 0, ySize)

        val uvPixelStride = image.planes[1].pixelStride
        if (uvPixelStride == 1) {
            vBuffer.get(nv21, ySize, vSize)
            uBuffer.get(nv21, ySize + vSize, uSize)
        } else {
            val vByte = ByteArray(vSize)
            val uByte = ByteArray(uSize)
            vBuffer.get(vByte)
            uBuffer.get(uByte)

            var offset = ySize
            val chromaWidth = image.width / 2
            val chromaHeight = image.height / 2

            for (row in 0 until chromaHeight) {
                for (col in 0 until chromaWidth) {
                    val vIndex = row * image.planes[2].rowStride + col * uvPixelStride
                    val uIndex = row * image.planes[1].rowStride + col * uvPixelStride

                    if (vIndex < vByte.size && offset < nv21.size) {
                        nv21[offset++] = vByte[vIndex]
                    }
                    if (uIndex < uByte.size && offset < nv21.size) {
                        nv21[offset++] = uByte[uIndex]
                    }
                }
            }
        }
        return nv21
    }

    @SuppressLint("MissingPermission")
    fun startAudioStream(onAudioLevel: (Float) -> Unit) {
        if (isAudioStreaming.get()) return
        try {
            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            audioRecord?.startRecording()
            isAudioStreaming.set(true)
            audioJob = scope.launch {
                val buffer = ShortArray(bufferSize)
                while (isActive && isAudioStreaming.get()) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        var maxAmp = 0
                        for (i in 0 until read) {
                            val abs = Math.abs(buffer[i].toInt())
                            if (abs > maxAmp) maxAmp = abs
                        }
                        val normalized = (maxAmp / 32768f).coerceIn(0f, 1f)
                        onAudioLevel(normalized)
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e("CameraStreamManager", "Audio permission missing", e)
        } catch (e: Exception) {
            Log.e("CameraStreamManager", "Failed to start audio record", e)
        }
    }

    fun stopCameraStream() {
        isCameraStreaming.set(false)
        fallbackJob?.cancel()
        try {
            cameraProvider?.unbindAll()
            streamLifecycleOwner?.markDestroyed()
            streamLifecycleOwner = null
        } catch (e: Exception) {
            Log.w("CameraStreamManager", "Error unbinding camera: ${e.message}")
        }
    }

    fun stopAudioStream() {
        isAudioStreaming.set(false)
        try {
            audioJob?.cancel()
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.w("CameraStreamManager", "Error releasing audio record: ${e.message}")
        }
    }

    fun stopStreaming() {
        stopCameraStream()
        stopAudioStream()
    }
}
