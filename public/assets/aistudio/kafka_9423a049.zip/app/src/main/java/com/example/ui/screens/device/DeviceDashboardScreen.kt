package com.example.ui.screens.device

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Device
import com.example.data.model.Session
import com.example.data.repository.HomeSafeRepository
import com.example.service.HomeSafeForegroundService
import com.example.ui.components.AudioWaveformMeter
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.StreamingCyan
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.launch

@Composable
fun DeviceDashboardScreen(
    targetDeviceId: String,
    targetDeviceName: String,
    pairedMonitorId: String?,
    repository: HomeSafeRepository,
    onPairWithMonitor: () -> Unit,
    onOpenSettings: () -> Unit,
    onUnpaired: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Real-time Firestore listeners for Device and Session
    val myDevice by repository.observeDevice(targetDeviceId).collectAsState(initial = null)
    val pairedMonitorDevice by remember(pairedMonitorId) {
        if (!pairedMonitorId.isNullOrBlank()) {
            repository.observeDevice(pairedMonitorId)
        } else {
            kotlinx.coroutines.flow.flowOf(null)
        }
    }.collectAsState(initial = null)

    val activeSession by repository.observeActiveSessionForDevice(targetDeviceId).collectAsState(initial = null)

    val isCamAuth = myDevice?.persistentCameraAuthorized == true
    val isMicAuth = myDevice?.persistentMicAuthorized == true

    val isCameraActive = activeSession?.isCameraActive == true
    val isMicActive = activeSession?.isMicActive == true
    val isAnyStreaming = isCameraActive || isMicActive

    // Automatically request required Android permissions on startup
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Permissions result handled
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        val notGranted = permissionsToRequest.filter { perm ->
            androidx.core.content.ContextCompat.checkSelfPermission(context, perm) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            permissionLauncher.launch(notGranted.toTypedArray())
        }
        // Auto-authorize persistent camera & mic so user never has to click manual toggles
        try {
            repository.setPersistentCameraAuth(targetDeviceId, true)
            repository.setPersistentMicAuth(targetDeviceId, true)
        } catch (e: Exception) {
            android.util.Log.w("DeviceDashboard", "Auto auth error: ${e.message}")
        }
    }

    // Intercept back button when paired: Cannot exit device mode until unpaired on monitoring device
    BackHandler(enabled = !pairedMonitorId.isNullOrBlank()) {
        android.widget.Toast.makeText(
            context,
            "Device Mode is locked. Unpair from your monitoring phone to exit.",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }

    // Automatically detect when monitoring phone unpairs this device
    LaunchedEffect(myDevice?.unpairedByRemote, myDevice?.pairedWithDeviceId) {
        val dev = myDevice ?: return@LaunchedEffect
        if (!pairedMonitorId.isNullOrBlank()) {
            if (dev.unpairedByRemote || dev.pairedWithDeviceId.isBlank()) {
                android.widget.Toast.makeText(
                    context,
                    "Unpaired by Monitoring device. Exiting Device Mode.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
                repository.clearUnpairedByRemoteFlag(targetDeviceId)
                onUnpaired()
            }
        }
    }

    // Update heartbeat and keep foreground service active safely
    LaunchedEffect(targetDeviceId) {
        try {
            repository.updateDeviceHeartbeat(targetDeviceId, isOnline = true)
        } catch (e: Exception) {
            android.util.Log.w("DeviceDashboard", "Heartbeat update: ${e.message}")
        }
        try {
            HomeSafeForegroundService.startService(context, targetDeviceId)
        } catch (e: Exception) {
            android.util.Log.w("DeviceDashboard", "Foreground service start: ${e.message}")
        }
    }

    val cameraManager = remember { com.example.camera.CameraStreamManager(context.applicationContext) }
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current

    // Direct foreground Activity camera streaming to ensure 100% Android OS camera access
    LaunchedEffect(isCameraActive, activeSession?.cameraLens, activeSession?.sessionId) {
        val session = activeSession
        val sId = session?.sessionId
        if (isCameraActive && !sId.isNullOrBlank()) {
            val useFront = session.cameraLens.contains("front", ignoreCase = true)
            cameraManager.startCameraStream(
                lifecycleOwner = lifecycleOwner,
                previewView = null,
                useFrontCamera = useFront,
                deviceName = targetDeviceName,
                onFrameCaptured = { base64 ->
                    scope.launch {
                        repository.pushVideoFrame(sId, base64)
                    }
                }
            )
        } else {
            cameraManager.stopCameraStream()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraManager.stopCameraStream()
        }
    }

    Scaffold(
        containerColor = MidnightBg,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Kafka Device",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "CP B • $targetDeviceName",
                        style = MaterialTheme.typography.bodySmall,
                        color = StreamingCyan
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (pairedMonitorId.isNullOrBlank()) {
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.testTag("device_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = Color.White
                            )
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = WarningAmber.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("LOCKED", color = WarningAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (isCameraActive) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF071C17)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberEmerald)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(AlertCoral.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = null,
                                    tint = AlertCoral,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).background(AlertCoral, CircleShape))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LIVE CAMERA STREAMING",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = AlertCoral
                                    )
                                }
                                Text(
                                    text = "Transmitting ${if (activeSession?.cameraLens?.contains("front", ignoreCase = true) == true) "Front" else "Rear"} camera feed to ${pairedMonitorDevice?.deviceName ?: "Monitoring Phone"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // When paired or unpaired, render the Paired Monitor Info Card matching Screenshot 3
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = StreamingCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Paired Monitor (CP A)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            if (!pairedMonitorId.isNullOrBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = CyberEmerald.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "PAIRED",
                                        color = CyberEmerald,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (!pairedMonitorId.isNullOrBlank()) {
                            Text(
                                text = pairedMonitorDevice?.deviceName ?: "Monitoring Phone",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Device ID: $pairedMonitorId",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = SurfaceVariantDark,
                                border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = WarningAmber,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Device Mode Locked",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "This phone cannot exit Device Mode until unpaired from the monitoring phone.",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = "No monitoring device currently paired.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = onPairWithMonitor,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald, contentColor = Color(0xFF022C22))
                            ) {
                                Text("Pair With Monitor", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
