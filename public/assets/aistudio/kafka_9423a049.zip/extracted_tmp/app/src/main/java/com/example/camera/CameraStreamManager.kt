package com.example.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class BackgroundStreamLifecycleOwner : LifecycleOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    init {
        val looper = android.os.Looper.getMainLooper()
        if (android.os.Looper.myLooper() == looper) {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        } else {
            android.os.Handler(looper).post {
                lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
                lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
                lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
            }
        }
    }

    fun markResumed() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
    }

    fun markDestroyed() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        }
    }
}

class CameraStreamManager(private val context: Context) {

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var isCameraStreaming = AtomicBoolean(false)
    private var isAudioStreaming = AtomicBoolean(false)
    private var lastFrameTime = 0L
    private val frameIntervalMs = 700L // Optimal rate for smooth Firestore synchronization without throttling
    private var streamLifecycleOwner: BackgroundStreamLifecycleOwner? = null

    private var audioRecord: AudioRecord? = null
    private var audioJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    fun startCameraStream(
        lifecycleOwner: LifecycleOwner? = null,
        previewView: PreviewView?,
        useFrontCamera: Boolean,
        onFrameCaptured: (String) -> Unit
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()
                cameraProvider?.unbindAll()

                val cameraSelector = if (useFrontCamera && cameraProvider?.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) == true) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    processImage(imageProxy, onFrameCaptured)
                }

                val useCases = mutableListOf<androidx.camera.core.UseCase>(imageAnalysis)

                previewView?.let { pv ->
                    try {
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(pv.surfaceProvider)
                        }
                        useCases.add(preview)
                    } catch (e: Exception) {
                        Log.w("CameraStreamManager", "Preview surface attach skipped: ${e.message}")
                    }
                }

                // If no specific lifecycleOwner provided, use persistent BackgroundStreamLifecycleOwner
                val bgOwner = streamLifecycleOwner ?: BackgroundStreamLifecycleOwner().also {
                    streamLifecycleOwner = it
                }
                bgOwner.markResumed()
                val owner: LifecycleOwner = lifecycleOwner ?: bgOwner

                cameraProvider?.bindToLifecycle(
                    owner,
                    cameraSelector,
                    *useCases.toTypedArray()
                )
                isCameraStreaming.set(true)
                Log.d("CameraStreamManager", "Camera stream successfully bound and running")
            } catch (e: Exception) {
                Log.e("CameraStreamManager", "Failed to start camera", e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun processImage(imageProxy: ImageProxy, onFrameCaptured: (String) -> Unit) {
        try {
            if (!isCameraStreaming.get()) {
                return
            }

            val currentTime = System.currentTimeMillis()
            if (currentTime - lastFrameTime < frameIntervalMs) {
                return
            }
            lastFrameTime = currentTime

            val originalBitmap = try {
                imageProxy.toBitmap()
            } catch (e: Exception) {
                try {
                    val plane = imageProxy.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * imageProxy.width
                    val bmp = Bitmap.createBitmap(
                        imageProxy.width + rowPadding / pixelStride,
                        imageProxy.height,
                        Bitmap.Config.ARGB_8888
                    )
                    bmp.copyPixelsFromBuffer(buffer)
                    if (rowPadding != 0) {
                        Bitmap.createBitmap(bmp, 0, 0, imageProxy.width, imageProxy.height)
                    } else {
                        bmp
                    }
                } catch (e2: Exception) {
                    val nv21 = yuv420ToNv21(imageProxy)
                    val yuvImage = YuvImage(nv21, ImageFormat.NV21, imageProxy.width, imageProxy.height, null)
                    val out = ByteArrayOutputStream()
                    yuvImage.compressToJpeg(Rect(0, 0, imageProxy.width, imageProxy.height), 40, out)
                    val imageBytes = out.toByteArray()
                    BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                }
            }

            if (originalBitmap != null) {
                val scale = 360f / originalBitmap.width.coerceAtLeast(1)
                val newWidth = (originalBitmap.width * scale).toInt().coerceAtLeast(1)
                val newHeight = (originalBitmap.height * scale).toInt().coerceAtLeast(1)
                val scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, newWidth, newHeight, true)

                val scaledOut = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 60, scaledOut)
                val base64 = Base64.encodeToString(scaledOut.toByteArray(), Base64.NO_WRAP)

                onFrameCaptured(base64)
                scaledBitmap.recycle()
                originalBitmap.recycle()
            }
        } catch (e: Exception) {
            Log.e("CameraStreamManager", "Error processing image frame", e)
        } finally {
            imageProxy.close()
        }
    }

    private fun yuv420ToNv21(image: ImageProxy): ByteArray {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + image.width * image.height / 2)

        yBuffer.get(nv21, 0, ySize)

        val uvPixelStride = image.planes[1].pixelStride
        if (uvPixelStride == 1) {
            vBuffer.get(nv21, ySize, vSize)
            uBuffer.get(nv21, ySize + vSize, uSize)
        } else {
            val vByte = ByteArray(vSize)
            val uByte = ByteArray(uSize)
            vBuffer.get(vByte)
            uBuffer.get(uByte)

            var offset = ySize
            val chromaWidth = image.width / 2
            val chromaHeight = image.height / 2

            for (row in 0 until chromaHeight) {
                for (col in 0 until chromaWidth) {
                    val vIndex = row * image.planes[2].rowStride + col * uvPixelStride
                    val uIndex = row * image.planes[1].rowStride + col * uvPixelStride

                    if (vIndex < vByte.size && offset < nv21.size) {
                        nv21[offset++] = vByte[vIndex]
                    }
                    if (uIndex < uByte.size && offset < nv21.size) {
                        nv21[offset++] = uByte[uIndex]
                    }
                }
            }
        }
        return nv21
    }

    @SuppressLint("MissingPermission")
    fun startAudioStream(onAudioLevel: (Float) -> Unit) {
        if (isAudioStreaming.get()) return
        try {
            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            audioRecord?.startRecording()
            isAudioStreaming.set(true)
            audioJob = scope.launch {
                val buffer = ShortArray(bufferSize)
                while (isActive && isAudioStreaming.get()) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        var maxAmp = 0
                        for (i in 0 until read) {
                            val abs = Math.abs(buffer[i].toInt())
                            if (abs > maxAmp) maxAmp = abs
                        }
                        val normalized = (maxAmp / 32768f).coerceIn(0f, 1f)
                        onAudioLevel(normalized)
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e("CameraStreamManager", "Audio permission missing", e)
        } catch (e: Exception) {
            Log.e("CameraStreamManager", "Failed to start audio record", e)
        }
    }

    fun stopCameraStream() {
        isCameraStreaming.set(false)
        try {
            cameraProvider?.unbindAll()
            streamLifecycleOwner?.markDestroyed()
            streamLifecycleOwner = null
        } catch (e: Exception) {
            Log.w("CameraStreamManager", "Error unbinding camera: ${e.message}")
        }
    }

    fun stopAudioStream() {
        isAudioStreaming.set(false)
        try {
            audioJob?.cancel()
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.w("CameraStreamManager", "Error releasing audio record: ${e.message}")
        }
    }

    fun stopStreaming() {
        stopCameraStream()
        stopAudioStream()
    }
}
