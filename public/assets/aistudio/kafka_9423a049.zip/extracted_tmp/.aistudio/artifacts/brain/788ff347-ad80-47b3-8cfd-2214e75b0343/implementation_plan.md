# HomeSafe - Persistent Camera & Microphone Authorization System

This update enhances **HomeSafe** with a persistent authorization architecture for consenting, paired devices. Once the owner of **CP B (Device Mode)** explicitly grants persistent authorization, **CP A (Monitoring Mode)** can seamlessly toggle Camera (Front/Rear) and Microphone ON and OFF without requiring repetitive in-app approval prompts for each activation, while ensuring complete background transparency and immediate revocation controls.

***

### User Review & Critical Decisions

> [!IMPORTANT]
> The following operational preferences have been confirmed and incorporated:

- **Confirmed Decision 1 (Background Stream Activation)**: When CP A toggles the camera or microphone ON, CP B's Android Foreground Service automatically activates the capture pipeline in the background and presents an ongoing high-priority notification with privacy indicators.
- **Confirmed Decision 2 (Authorization Lifecycle)**: Persistent authorizations remain valid indefinitely until explicitly revoked by the CP B device owner or upon unpairing.
- **Confirmed Decision 3 (Audio Synchronization)**: Microphone audio is captured and synchronized alongside the live video feed, accompanied by an interactive real-time audio waveform/volume meter on CP A.
- **Confirmed Decision 4 (Granular & Independent Control)**: Camera authorization and Microphone authorization are stored and toggled as independent permissions (`persistentCameraAuthorized` and `persistentMicAuthorized`). Revoking either immediately terminates that specific stream.

***

## 1. Overview & Core Concept

While the previous version enforced a prompt on CP B for every single session attempt, this upgrade allows the consenting owner of CP B to delegate persistent access to their trusted CP A monitor. 

- **Target Persona**: Dedicated home security devices, nursery monitors, pet cams, or assisted living setups where CP B is placed in a fixed location and cannot be physically tapped each time a family member checks in.
- **Privacy Standard**: Zero stealth access. Even when persistent authorization is active, CP B always presents persistent status indicators, an active foreground notification, and an instantaneous kill-switch to revoke access at any time.

***

## 2. User Experience & Visual Design

### Key User Flows

1. **First-Time Authorization in Permission Wizard (CP B)**:
   - In addition to standard Android runtime permission cards (Camera, Mic, GPS, Notifications), the wizard includes a dedicated authorization card:
     - *"Allow my paired monitoring device to access camera and microphone without repeated in-app approval."*
     - Clear toggles for:
       - **Allow Persistent Camera Access**
       - **Allow Persistent Microphone Access**
   - The device owner must explicitly toggle these ON.
   - Saved securely in Firestore under `devices/{deviceId}`.

2. **Monitor Mode Controls (CP A)**:
   - The device details card on CP A features active toggle switches:
     - **Camera**: `[ON / OFF]` switch with instant front/rear camera selection.
     - **Microphone**: `[ON / OFF]` switch with live audio amplitude waveform meter.
   - If persistent authorization is enabled on CP B:
     - Tapping `ON` immediately starts streaming without waiting for approval.
     - Tapping `OFF` closes the stream and releases the hardware.
     - Reopening the camera reuses the persistent token seamlessly.
   - If persistent authorization is NOT enabled:
     - Reverts gracefully to requesting single-session approval on CP B.

3. **Background Streaming & Minimization (CP B)**:
   - When CP A turns Camera or Mic ON, CP B's `HomeSafeForegroundService` starts with `FOREGROUND_SERVICE_TYPE_CAMERA | FOREGROUND_SERVICE_TYPE_MICROPHONE`.
   - Streaming continues uninterrupted when HomeSafe is minimized or screen is turned off.
   - Persistent notification displays: *"HomeSafe • Active Camera/Mic Sharing to Monitor"*, with a prominent red *"REVOKE / STOP"* button.
   - Automatic reconnection handles transient Wi-Fi/cellular handoffs.

4. **Device Owner Controls & Revocation (CP B)**:
   - **Privacy Management Panel** on CP B Dashboard:
     - Status: *"Persistent Camera: AUTHORIZED"* / *"Persistent Mic: AUTHORIZED"*
     - Action: **Revoke Camera Authorization** (instantly severs camera stream)
     - Action: **Revoke Microphone Authorization** (instantly severs audio stream)
     - Action: **Stop All Sharing & Revoke All** (emergency kill-switch)
   - Live banner actively shows if streaming is currently transmitting or idle.

***

## 3. Key Technical Architecture & Implementation Steps

### System State & Signaling Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Cloud Firestore Backend                         │
│                                                                        │
│  /devices/{deviceId}                                                   │
│  ├── persistentCameraAuthorized: Boolean                               │
│  ├── persistentMicAuthorized: Boolean                                  │
│  ├── pairedWithDeviceId: String (Monitor CP A)                         │
│  └── activeSession: { cameraActive, micActive, cameraLens, ... }       │
└───────────────▲───────────────────────────────────────▲────────────────┘
                │                                       │
     Toggle Camera / Mic ON/OFF             Observe & Auto-Launch
     (Direct Session State)                 (Background Service)
                │                                       │
┌───────────────┴──────────────┐        ┌───────────────┴────────────────┐
│      CP A (Monitor Mode)     │        │       CP B (Device Mode)       │
│                              │        │                                │
│ ┌──────────────────────────┐ │        │ ┌────────────────────────────┐ │
│ │ Camera Switch: [ ON/OFF ]│ │        │ │ HomeSafeForegroundService  │ │
│ │ Lens: [ Front / Rear ]   │ │        │ │ (Keeps Capture Alive)      │ │
│ └──────────────────────────┘ │        │ └──────────────┬─────────────┘ │
│ ┌──────────────────────────┐ │        │ ┌──────────────▼─────────────┐ │
│ │ Mic Switch:    [ ON/OFF ]│ │        │ │ CameraX & Audio Capture    │ │
│ │ Waveform Amplitude Meter │ │        │ │ Stream Pipeline            │ │
│ └──────────────────────────┘ │        │ └──────────────┬─────────────┘ │
│ ┌──────────────────────────┐ │        │ ┌──────────────▼─────────────┐ │
│ │ Live Stream Canvas View  │◄├────────┼─┤ Revocation Control Card:   │ │
│ └──────────────────────────┘ │        │ │ [Revoke Cam] [Revoke Mic]  │ │
│                              │        │ └────────────────────────────┘ │
└──────────────────────────────┘        └────────────────────────────────┘
```

### Planned Code Updates

1. **Data Model Updates (`Models.kt`)**:
   - Add `persistentCameraAuthorized: Boolean = false` and `persistentMicAuthorized: Boolean = false` to `Device`.
   - Add `isMicActive: Boolean = false` and `isCameraActive: Boolean = false` to `Session` for independent ON/OFF controls.
   - Add `audioLevel: Float = 0f` to stream telemetry.

2. **Repository Enhancements (`HomeSafeRepository.kt`)**:
   - Add `updatePersistentAuthorization(deviceId: String, cameraAuth: Boolean, micAuth: Boolean)`.
   - Add `toggleCameraState(sessionId: String, targetDeviceId: String, active: Boolean, lens: SessionType)`.
   - Add `toggleMicrophoneState(sessionId: String, targetDeviceId: String, active: Boolean)`.
   - Add `revokeAuthorizationAndKillStreams(deviceId: String, revokeCamera: Boolean, revokeMic: Boolean)`.

3. **Background Service & Auto-Activation (`HomeSafeForegroundService.kt`)**:
   - Enhance the service to react to active stream toggles from Firestore even when the app is in the background.
   - Bind `CameraX` capture lifecycle with headless analysis when app is minimized.
   - Maintain persistent ongoing notification with dynamic status ("Camera Streaming", "Mic Active", "Idle & Authorized").

4. **Permission Setup & Onboarding (`PermissionWizardScreen.kt`)**:
   - Add the explicit *"Persistent Authorization"* consent card during initial setup.
   - Clear privacy disclosures so the device owner explicitly understands that this enables remote activation without a pop-up.

5. **Device Dashboard (`DeviceDashboardScreen.kt`)**:
   - Add dedicated Persistent Authorization settings cards.
   - Separate buttons to "Revoke Camera", "Revoke Microphone", and "Stop All Sharing".
   - Real-time stream indicator.

6. **Monitoring Dashboard (`MonitoringDashboardScreen.kt`)**:
   - Replace one-time request buttons with active **Camera ON/OFF** and **Microphone ON/OFF** switches.
   - Front/Rear camera switcher available while camera is ON.
   - Real-time audio waveform meter component.
   - Connection status pill (CONNECTED, STREAMING, AUTHORIZED, RECONNECTED).

7. **Verification & Testing**:
   - Execute test cases verifying repeated camera ON/OFF, microphone ON/OFF, app minimization, and immediate stream cutoff on authorization revocation.
